Download or see the full example at
https://github.com/rdksl/RangeFilter-Module-for-Framer


INSTALL:
1. Copy ›RangeFilter.coffee‹ to your prototype’s ›modules‹ folder
2. Call {RangeFilter} = require "RangeFilter" in your prototype.

USE:
priceyCoats = new RangeFilter
	from: 499
	to: 2899


CUSTOMIZABLE FEATURES:
from
to
bottom
top
width
height
backgroundColor
borderRadius
activeRange
knobColor
knobSize
knobRadius
knobBorder
knobBorderColor
knobShadowColor
showValue
valueColor
valueSize
currency